import { getData, postData, request } from './request';

export const forgotPassword = ({ email }: { email: string }) =>
    request.post('/auth/forgot-password', { email });

export const resetPassword = ({
    email,
    password,
    token
}: {
    email: string;
    password: string;
    token: string;
}) => request.post('/auth/reset-password', { email, password, token });

export const login = (credentials: any) =>
    request.post('/api/auth/login', credentials);

export const logout = () => postData('/api/auth/logout', {});

export const register = (credentials: {
    name: string;
    email: string;
    password: string;
}) => request.post('/api/auth/signup', credentials);

export const activation = (email: string, token: string) =>
    request.post('/api/auth/activation', { email, token });

// TODO: make resendActivation works
export const resendActivation = ({ email }: { email: string }) =>
    request.post('/api/auth/resend-activation', { email });

export const verify = () => getData('/api/auth/verify');

export const googleOAuthCallback = (code: string) =>
    request.post('/api/auth/oauth/google/callback', { code });
