export default function Account() {
    return <div>Account</div>;
}
