export default function Tasks() {
    return <div>Tasks</div>;
}
