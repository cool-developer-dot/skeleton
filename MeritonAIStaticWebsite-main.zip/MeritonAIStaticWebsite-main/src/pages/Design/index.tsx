import ExampleApp from '@components/Example/ExampleApp';

export default function Design() {
    return (
        <div>
            <ExampleApp />
        </div>
    );
}
