import React from 'react';
// import { thirdLoginMutation } from '@api/portal-service/thirdLoginMutation';
// import { useMutation } from '@tanstack/react-query';
import { Button } from '@mui/material';
import { GoogleIcon } from '@pages/Authentication/SignIn/CustomIcons';
const GOOGLE_OAUTH_CLIENT_ID = import.meta.env.VITE_GOOGLE_OAUTH_CLIENT_ID;
const GOOGLE_OAUTH_REDIRECT_URL = import.meta.env
    .VITE_GOOGLE_OAUTH_REDIRECT_URL;

const GoogleLoginButton: React.FC<{ demo?: boolean }> = () => {
    const handleGoogleLogin = () => {
        const url = new URL('https://accounts.google.com/o/oauth2/v2/auth');

        const query = new URLSearchParams({
            client_id: GOOGLE_OAUTH_CLIENT_ID,
            redirect_uri: GOOGLE_OAUTH_REDIRECT_URL,
            response_type: 'code', // Use 'code' for Authorization Code flow
            scope: 'openid email profile'
        });
        url.search = new URLSearchParams(query).toString();

        window.location.href = url.toString();
    };

    return (
        <Button
            fullWidth
            variant="outlined"
            onClick={handleGoogleLogin}
            startIcon={<GoogleIcon />}
        >
            Continue with Google
        </Button>
    );
};

export default GoogleLoginButton;
