import { Typography } from '@mui/material';

export default function Users() {
    return <Typography variant="h1">Users</Typography>;
}
